//: Playground - noun: a place where people can play

import UIKit


func countFrom(from:Int,to: Int) {
    if from <= to {
        print(from)
        countFrom(from + 1, to: to)
    }
}

countFrom(10, to: 15)