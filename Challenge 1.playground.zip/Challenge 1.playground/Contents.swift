//: Playground - noun: a place where people can play

/* 
 Task: Your first challenge is to write a function that takes two variables (of any type) as parameters and swaps their values.
 
 Requirements:
 For the function body use a single line of code */



func Switch(inout object1:Int, inout _ object2:Int) {
   (object1,object2) = (object2,object1)
}

var a = 10, b = 20
Switch(&a, &b)

print(a)
print(b)