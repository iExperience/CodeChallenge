//: Playground - noun: a place where people can play

/* Task: 
 
 Write a function called sumAny that can take 0 or more parameters of any type. The function should meet the following requirements:
 The function will return the sum of the passed parameters as a String, following the rules below.
 If a parameter is an empty string or an Int equal to 0, add -10 to the result.
 If a parameter is an String that represents a positive number (e.g. “10”, not “-5”), add it to the result.
 If a parameter is an Int, add it to the result.
 In any other case, do not add it to the result.
 For an extra shuriken – write the function as a single return statement and don’t use any loops (i.e. no for or while).
 */

func sumAny(numbers: Any...) -> String {
    var total: Int = 0
  
    for number in numbers {
        switch number {
     
        case 0 as Int:
            total += -10
        case "" as String:
            total += -10
        case let num as String where Int(num) > 0:
            total += Int(num)!
        case let num2 as Int:
            total += num2
        default:
            total += 0
        }
    }
    return String(total)
}



var test1:Any = 10

print(sumAny(test1))
print(sumAny(10,"","asdfasd",0,"30"))



