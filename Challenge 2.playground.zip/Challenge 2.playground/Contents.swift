//: Playground - noun: a place where people can play

/* Task: 
 For this challenge you’ll test your understanding of function syntax in Swift. Write a function called flexStrings that meets the following requirements:
 The function can take precisely 0, 1 or 2 string parameters.
 Returns the function parameters concatenated as String.
 If no parameters pass to the function, it will return the string “none”.
 For an extra shuriken use one line of code for the function body.
 */


func flexStrings(string1: String = "",string2:String = "") -> String {
    return string1 + string2 == "" ? "none": string1 + string2
}


let s1 = "a", s2 = "b"

print(flexStrings(s1,string2: s2))
print(flexStrings(s1))
print(flexStrings())